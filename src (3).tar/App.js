import { Route, Switch } from "react-router-dom";
import Home from "./components/home";
import Services from "./components/services";
import Projects from "./components/projects";
import Admin from "./components/admin";
import Login from "./components/login";
import "./App.css";

const App = () => (
  <>
    <Route path="/login" component={Login} />
    <Switch>
      <Route exact path="/" component={Home} />
      <Route exact path="/services" component={Services} />
      <Route exact path="/projects" component={Projects} />
      <Route exact path="/admin" component={Admin} />
    </Switch>
  </>
);

export default App;
