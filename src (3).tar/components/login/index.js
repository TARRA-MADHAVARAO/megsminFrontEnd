import { Component } from "react";
import Cookies from "js-cookie";
import { createBrowserHistory } from "history";
import "./index.css";

class Login extends Component {
  state = { username: "", password: "" };

  changePassword = (event) => {
    this.setState({ password: event.target.value });
  };

  changeUsername = (event) => {
    this.setState({ username: event.target.value });
  };

  loginForm = async (event) => {
    event.preventDefault();
    const { username, password } = this.state;
    const userDetails = {
      userName: username,
      password: password,
    };
    const url = `https://righteous-honorable-leader.glitch.me/login`;
    const options = {
      method: "POST",
      body: JSON.stringify(userDetails),
      headers: {
        "Content-type": "application/json; charset=UTF-8",
      },
    };
    const response = await fetch(url, options);
    const data = await response.json();
    if (response.status === 200) {
      const history = createBrowserHistory();
      history.push("/");
      const jwtToken = data.jwtToken;
      Cookies.set("jwt_token", jwtToken, { expires: 30 });
    } else {
      console.log(data.error);
    }
  };

  render() {
    const { username, password } = this.state;
    return (
      <div className="login-bg">
        <form className="form" onSubmit={this.loginForm}>
          <label htmlFor="username">USERNAME</label>
          <br />
          <input
            onChange={this.changeUsername}
            type="text"
            placeholder="username"
            id="username"
            value={username}
          />
          <br />
          <label htmlFor="password">PASSWORD</label>
          <br />
          <input
            value={password}
            onChange={this.changePassword}
            type="password"
            placeholder="password"
            id="password"
          />
          <br />
          <button className="login-btn" type="submit">
            Login
          </button>
          <button className="login-btn sign-up" type="button">
            SignUp
          </button>
        </form>
      </div>
    );
  }
}

export default Login;
