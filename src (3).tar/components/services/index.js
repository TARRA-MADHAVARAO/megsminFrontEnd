import { Component } from "react";
import Header from "../header";

class Services extends Component {
  state = { services: [] };

  componentDidMount() {
    this.getServices();
  }

  getServices = async () => {
    const url = `https://righteous-honorable-leader.glitch.me/services`;
    const response = await fetch(url);
    const data = await response.json();
    this.setState({ services: data });
  };

  deletePro = async (event) => {
    const id = event.target.id;
    const url = `https://righteous-honorable-leader.glitch.me/services/${id}`;
    const options = {
      method: "DELETE",
    };
    await fetch(url, options);
    this.setState({ status: false });
  };

  render() {
    const { services } = this.state;
    return (
      <div>
        <Header />
        <ul>
          {services.map((each) => (
            <li key={each.id}>
              <h1>{each.name}</h1>
              <p>{each.description}</p>
              <button type="button" id={each.id} onClick={this.deletePro}>
                Delete
              </button>
            </li>
          ))}
        </ul>
      </div>
    );
  }
}

export default Services;
