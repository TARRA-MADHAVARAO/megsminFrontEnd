import { Component } from "react";
import Header from "../header";

class Projects extends Component {
  state = { projects: [], status: true };

  componentDidMount() {
    this.getProducts();
  }

  getProducts = async () => {
    const url = `https://righteous-honorable-leader.glitch.me/projects`;
    const response = await fetch(url);
    const data = await response.json();
    this.setState({ projects: data });
  };

  deletePro = async (event) => {
    const id = event.target.id;
    const url = `https://righteous-honorable-leader.glitch.me/projects/${id}`;
    const options = {
      method: "DELETE",
    };
    await fetch(url, options);
    this.setState({ status: false });
  };

  render() {
    const { projects } = this.state;
    return (
      <div>
        <Header />
        <ul>
          {projects.map((each) => (
            <li key={each.id}>
              <h1>{each.name}</h1>
              <p>{each.description}</p>
              <button type="button" id={each.id} onClick={this.deletePro}>
                Delete
              </button>
            </li>
          ))}
        </ul>
      </div>
    );
  }
}
export default Projects;
